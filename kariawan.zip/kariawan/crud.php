<?php
include 'functions.php';
// Your PHP code here.

// Home Page template below.
?>

<?=template_header('Home')?>

<div class="content">
	
	<style>

body {
  background-image: url('pt rhm.id.jpg');
  background-size: cover;
}

</style>
</div>

<?=template_footer()?>